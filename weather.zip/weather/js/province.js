/*
 * @Author: huangchengdu
 * @Date:   2016-11-23 11:59:35
 * @Last Modified by:   huangchengdu
 * @Last Modified time: 2016-11-23 18:47:15
 */

export default [
        { "n": "北京", "i": "11", "s": "beijing" },
        { "n": "天津", "i": "12", "s": "tianjin" },
        { "n": "河北", "i": "13", "s": "hebei" },
        { "n": "山西", "i": "14", "s": "shanxi" },
        { "n": "内蒙古", "i": "15", "s": "neimenggu" },
        { "n": "辽宁", "i": "21", "s": "liaoning" },
        { "n": "吉林", "i": "22", "s": "jilin" },
        { "n": "黑龙江", "i": "23", "s": "heilongjiang" },
        { "n": "上海", "i": "31", "s": "shanghai" },
        { "n": "江苏", "i": "32", "s": "jiangsu" },
        { "n": "浙江", "i": "33", "s": "zhejiang" },
        { "n": "安徽", "i": "34", "s": "anhui" },
        { "n": "福建", "i": "35", "s": "fujian" },
        { "n": "江西", "i": "36", "s": "jiangxi" },
        { "n": "山东", "i": "37", "s": "shandong" },
        { "n": "河南", "i": "41", "s": "henan" },
        { "n": "湖北", "i": "42", "s": "hubei" },
        { "n": "湖南", "i": "43", "s": "hunan" },
        { "n": "广东", "i": "44", "s": "guangdong" },
        { "n": "广西", "i": "45", "s": "guangxi" },
        { "n": "海南", "i": "46", "s": "hainan" },
        { "n": "重庆", "i": "50", "s": "chongqing" },
        { "n": "四川", "i": "51", "s": "sichuan" },
        { "n": "贵州", "i": "52", "s": "guizhou" },
        { "n": "云南", "i": "53", "s": "yunnan" },
        { "n": "西藏", "i": "54", "s": "xicang" },
        { "n": "陕西", "i": "61", "s": "shanxi" },
        { "n": "甘肃", "i": "62", "s": "gansu" },
        { "n": "青海", "i": "63", "s": "qinghai" },
        { "n": "宁夏", "i": "64", "s": "ningxia" },
        { "n": "新疆", "i": "65", "s": "xinjiang" }
    ]
